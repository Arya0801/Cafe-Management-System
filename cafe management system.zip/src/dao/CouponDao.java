/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Coupon;

/**
 *
 * @author ASUS
 */
public class CouponDao {
    public static void save(Coupon coupon){
        String query="insert into coupons(coupon_id,price) values ('"+coupon.getCoupon_id()+"','"+coupon.getPrice()+"')";
        DbOperations.setDataOrDelete(query,"Coupon added Successfully!");
        
    }
    
}
