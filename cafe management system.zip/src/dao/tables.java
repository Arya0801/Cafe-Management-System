/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class tables {
    public static void main(String[] args){
        try{
           // String userTable="create table user(id int AUTO_INCREMENT primary key,name varchar(200),email varchar(200),phone varchar(10),password varchar(200),securityquestion varchar(200),securityanswer varchar(200),status varchar(20),UNIQUE(email))";
            //String adminTable="create table admin(id varchar(20) primary key,password varchar(200))";
             //String itemTable="create table item(item_id varchar(10) primary key,item_name varchar(100),price varchar(10),category varchar(100))";
             //DbOperations.setDataOrDelete(itemTable,"Item Table Created Successfully!");
            // String order_infoTable="create table orderinfo(order_id varchar(10) primary key,email varchar(200),foreign key(email) references user(email))";
            // DbOperations.setDataOrDelete(order_infoTable,"order_info Table Created Successfully!");
           // String adminDetails="insert into user(name,email,phone,password,securityquestion,securityanswer,status) values('Admin','admin@gmail.com','9876543210','Admin@321','what is your first pet?','dog','true')";
            //DbOperations.setDataOrDelete(userTable,"User Table Created Successfully!");
            //DbOperations.setDataOrDelete(adminTable,"Admin Table Created Successfully!");
           // DbOperations.setDataOrDelete(adminDetails,"Admin details added Successfully!");
          // String order_dataTable="create table orderdata(order_id varchar(10),item_id varchar(10),price varchar(10),qty varchar(10),status varchar(20),foreign key(order_id) references orderinfo(order_id),foreign key(item_id) references item(item_id))";
            // DbOperations.setDataOrDelete(order_dataTable,"order_data Table Created Successfully!");
            // String couponsTable="create table coupons(coupon_id varchar(10) primary key,price varchar(10))";
             //DbOperations.setDataOrDelete(couponsTable,"coupons Table Created Successfully!");
            // String offerTable="create table offer(id varchar(50) primary key,percent varchar(50),status varchar(50))";
             //DbOperations.setDataOrDelete(offerTable,"offer Table Created Successfully!");
        }
    
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
    }
    
}
