/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Offer;

/**
 *
 * @author ASUS
 */
public class OfferDao {
     public static void save(Offer offer){
        String query="insert into offer(id,percent,status) values ('"+offer.getId()+"','"+offer.getPercent()+"','"+offer.getStatus()+"')";
        DbOperations.setDataOrDelete(query,"Offer Added Successfully!");
        
    }
    public static ArrayList<Offer> getAllOffers(){
        ArrayList<Offer> it=new ArrayList();
        String query="select * from offer";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Offer o=new Offer();
                o.setId(rs.getString("id"));
                o.setPercent(rs.getString("percent"));
                o.setStatus(rs.getString("status"));
                
                it.add(o);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
    
}
