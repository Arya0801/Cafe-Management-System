/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Item;
import java.sql.*;
import model.Offer;
/**
 *
 * @author romit
 */
public class ItemDao {
    
    public static ArrayList<Item> getAllSnacks(){
        ArrayList<Item> it=new ArrayList();
        String query="select * from item where category='snacks'";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Item item=new Item();
                item.setId(rs.getString("item_id"));
                item.setCategory(rs.getString("category"));
                item.setPrice(rs.getString("price"));
                item.setName(rs.getString("item_name"));
                it.add(item);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
    public static ArrayList<Item> getAllDrinks(){
        ArrayList<Item> it=new ArrayList();
        String query="select * from item where category='drinks'";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Item item=new Item();
                item.setId(rs.getString("item_id"));
                item.setCategory(rs.getString("category"));
                item.setPrice(rs.getString("price"));
                item.setName(rs.getString("item_name"));
                it.add(item);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
    public static ArrayList<Item> getAllCombos(){
        ArrayList<Item> it=new ArrayList();
        String query="select * from item where category='combos'";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Item item=new Item();
                item.setId(rs.getString("item_id"));
                item.setCategory(rs.getString("category"));
                item.setPrice(rs.getString("price"));
                item.setName(rs.getString("item_name"));
                it.add(item);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
    public static void save(Item item){
        String query="insert into item(item_id,item_name,price,category) values ('"+item.getId()+"','"+item.getName()+"','"+item.getPrice()+"','"+item.getCategory()+"')";
        DbOperations.setDataOrDelete(query,"Item Added Successfully!");
        
    }
     public static ArrayList<Item> getAllItems(){
        ArrayList<Item> it=new ArrayList();
        String query="select * from item";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Item o=new Item();
                o.setId(rs.getString("item_id"));
                o.setName(rs.getString("item_name"));
                o.setPrice(rs.getString("price"));
                o.setCategory(rs.getString("category"));
                
                it.add(o);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
   
    
}
