/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import javax.swing.JOptionPane;
import model.Admin;
import model.Admin;

/**
 *
 * @author ASUS
 */
public class AdminDao {
    public static void save(Admin admin){
        String query="insert into admin(id,password) values ('"+admin.getId()+"','"+admin.getPassword()+"')";
        DbOperations.setDataOrDelete(query,"Registered Successfully!");
        
    }
    public static Admin login(String id,String password){
        Admin admin=null;
        try{
            ResultSet rs=DbOperations.getData("select * from admin where id='"+id+"'and password='"+password+"'");
            while(rs.next())
            {
                admin=new Admin();
                //admin.setStatus(rs.getString("status"));
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        return admin;
    }
    
}
