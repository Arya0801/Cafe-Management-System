/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.OrderData;
import model.Order;

/**
 *
 * @author ASUS
 */
public class OrderDao {
    public static ArrayList<Order> getAllOrders(){
        ArrayList<Order> it=new ArrayList();
        
        String query="SELECT orderinfo.order_id, item.item_id, item.item_name, orderdata.price, orderdata.qty,orderinfo.email, orderinfo.date,orderdata.status FROM orderdata JOIN orderinfo ON orderdata.order_id = orderinfo.order_id JOIN item ON orderdata.item_id = item.item_id;";
        
        try{
            ResultSet rs = DbOperations.getData(query);
            while(rs.next()){
                Order o=new Order();
               
                o.setOrder_id(rs.getString("order_id"));
                 o.setItem_id(rs.getString("item_id")); 
                o.setName(rs.getString("item_name"));
                o.setPrice(rs.getString("price"));
                 o.setQty(rs.getString("qty"));
                o.setEmail(rs.getString("email"));
                o.setDate(rs.getDate("date"));
                o.setStatus(rs.getString("status"));
                
                it.add(o);
               
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        
        return it;
    }
   
}
